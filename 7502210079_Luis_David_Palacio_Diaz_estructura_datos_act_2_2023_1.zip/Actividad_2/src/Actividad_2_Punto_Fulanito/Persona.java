/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Persona {
    private String nombre;
    private LibretaProductos libretaProductos;
    private LibretaCompras libretaCompras;
    private LibretaClientes libretaClientes;
    private LibretaVentas libretaVentas;

    public Persona(String nombre) {
        this.nombre = nombre;
        this.libretaProductos = new LibretaProductos();
        this.libretaCompras = new LibretaCompras();
        this.libretaClientes = new LibretaClientes();
        this.libretaVentas = new LibretaVentas();
    }

    public void anotarProductoEnLibreta(int codigo, String nombre, String marca, String color, double precioCompra,
                                        double precioVenta, double porcentajeDescuentoMaximo, int unidadesExistencia,
                                        String metricaMedida, String categoria) {
        libretaProductos.anotarProductoEnLibreta(codigo, nombre, marca, color, precioCompra, precioVenta,
                porcentajeDescuentoMaximo, unidadesExistencia, metricaMedida, categoria);
    }

    public void anotarCompraEnLibreta(int consecutivo, String fecha, String proveedor, int codigoProducto,
                                      double precioCompra, double cantidad) {
        libretaCompras.anotarCompraEnLibreta(consecutivo, fecha, proveedor, codigoProducto, precioCompra, cantidad);
        actualizarProductoEnCompra(codigoProducto, precioCompra, cantidad);
    }

    private void actualizarProductoEnCompra(int codigoProducto, double precioCompra, double cantidad) {
        for (Producto producto : libretaProductos.getProductos()) {
            if (producto.getCodigo() == codigoProducto) {
                producto.setPrecioCompra(precioCompra);
                producto.setPrecioVenta(precioCompra * 0.4); // Precio de venta: 40% del precio de compra
                producto.setPorcentajeDescuentoMaximo(0.4); // Porcentaje máximo de descuento: 40%
                producto.setUnidadesExistencia(producto.getUnidadesExistencia() + (int) cantidad);
                break;
            }
        }
    }

    public void anotarClienteEnLibreta(String cedula, String nombre, String apellido1, String apellido2, String genero,
                                       String fechaNacimiento, String numeroTelefonico, String email, String direccion,
                                       boolean esVIP, double descuento) {
        libretaClientes.anotarClienteEnLibreta(cedula, nombre, apellido1, apellido2, genero, fechaNacimiento,
                numeroTelefonico, email, direccion, esVIP, descuento);
    }

    public void realizarVenta(int consecutivo, String fecha, String cedulaCliente, String medioPago,
                              String modalidad, List<ItemVenta> itemsVenta) {
        Venta venta = new Venta(consecutivo, fecha, cedulaCliente, medioPago, modalidad, itemsVenta);
        libretaVentas.anotarVentaEnLibreta(consecutivo, fecha, cedulaCliente, medioPago, modalidad, itemsVenta);
        actualizarEstadoVenta(consecutivo, true); // Cambiar estado de la venta a éxito
        actualizarExistenciaProductos(itemsVenta);
        actualizarEstadoCliente(cedulaCliente);
    }

    private void actualizarEstadoVenta(int consecutivo, boolean exito) {
        for (Venta venta : libretaVentas.getVentas()) {
            if (venta.getConsecutivo() == consecutivo) {
                if (exito) {
                    venta.setEstado("Éxito");
                } else {
                    venta.setEstado("Cancelada");
                    venta.setMotivoCancelacion("Motivo de cancelación"); // Agregar motivo de cancelación
                }
                break;
            }
        }
    }

    private void actualizarExistenciaProductos(List<ItemVenta> itemsVenta) {
        for (ItemVenta itemVenta : itemsVenta) {
            int codigoProducto = itemVenta.getCodigoProducto();
            double cantidad = itemVenta.getCantidad();
            for (Producto producto : libretaProductos.getProductos()) {
                if (producto.getCodigo() == codigoProducto) {
                    producto.setUnidadesExistencia(producto.getUnidadesExistencia() - (int) cantidad);
                    break;
                }
            }
        }
    }

private void actualizarEstadoCliente(String cedulaCliente) {
    for (Cliente cliente : libretaClientes.getClientes()) {
        if (cliente.getCedula().equals(cedulaCliente)) {
            cliente.setEsVIP(true); // Cambiar estado del cliente a VIP
            break;
        }
    }
}

    public void calcularBalanceFinanciero() {
        double totalInversionProductos = calcularTotalInversionProductos();
        double totalRecuperadoVentas = calcularTotalRecuperadoVentas();
        double totalGanancia = totalRecuperadoVentas - totalInversionProductos;
        double totalDescuento = calcularTotalDescuento();
        double totalIVA = calcularTotalIVA();

        System.out.println("Balance Financiero:");
        System.out.println("Total invertido en productos: $" + totalInversionProductos);
        System.out.println("Total recuperado en ventas: $" + totalRecuperadoVentas);
        System.out.println("Total ganancia: $" + totalGanancia);
        System.out.println("Total descuento generado: $" + totalDescuento);
        System.out.println("Total pagado como impuesto IVA: $" + totalIVA);
    }

    private double calcularTotalInversionProductos() {
        double totalInversion = 0.0;
        for (Compra compra : libretaCompras.getCompras()) {
            totalInversion += compra.getPrecioCompra() * compra.getCantidad();
        }
        return totalInversion;
    }

    private double calcularTotalRecuperadoVentas() {
        double totalRecuperado = 0.0;
        for (Venta venta : libretaVentas.getVentas()) {
            totalRecuperado += venta.getTotal();
        }
        return totalRecuperado;
    }

    private double calcularTotalDescuento() {
        double totalDescuento = 0.0;
        for (Venta venta : libretaVentas.getVentas()) {
            totalDescuento += venta.getTotalDescuento();
        }
        return totalDescuento;
    }

    private double calcularTotalIVA() {
        double totalIVA = 0.0;
        for (Venta venta : libretaVentas.getVentas()) {
            totalIVA += venta.getTotalIVA();
        }
        return totalIVA;
    }

    public List<Producto> obtenerProductosInversionRecomendada() {
        Map<Integer, Integer> ventasPorProducto = new HashMap<>();

        // Calcular la cantidad de ventas por producto
        for (Venta venta : libretaVentas.getVentas()) {
            for (ItemVenta itemVenta : venta.getItemsVenta()) {
                int codigoProducto = itemVenta.getCodigoProducto();
                ventasPorProducto.put(codigoProducto, ventasPorProducto.getOrDefault(codigoProducto, 0) + 1);
            }
        }

        List<Producto> productosInversionRecomendada = new ArrayList<>();

        // Obtener los productos que superan el 70% de las ventas
        for (Producto producto : libretaProductos.getProductos()) {
            int ventasProducto = ventasPorProducto.getOrDefault(producto.getCodigo(), 0);
            double porcentajeVentas = (double) ventasProducto / libretaVentas.getVentas().size() * 100;
            if (porcentajeVentas > 70) {
                productosInversionRecomendada.add(producto);
            }
        }

        return productosInversionRecomendada;
    }

    public void aplicarDescuentoProductosNoExitosos(List<Producto> productosInversionRecomendada) {
        for (Producto producto : libretaProductos.getProductos()) {
            if (!productosInversionRecomendada.contains(producto)) {
                double nuevoPrecioVenta = producto.getPrecioVenta() * 0.65; // 35% de descuento
                producto.setPrecioVenta(nuevoPrecioVenta);
            }
        }
    }

    public void mostrarProductosBajoExistencia() {
        System.out.println("Productos con existencia inferior a 5:");

        for (Producto producto : libretaProductos.getProductos()) {
            if (producto.getUnidadesExistencia() < 5) {
                System.out.println("Codigo: " + producto.getCodigo());
                System.out.println("Nombre: " + producto.getNombre());
                System.out.println("Existencia: " + producto.getUnidadesExistencia());
            }
        }
    }

   
public void informarDescuentosClientes() {
    double promedioCompras = calcularPromedioCompras();

    for (Cliente cliente : libretaClientes.getClientes()) {
        int cantidadCompras = contarComprasCliente(cliente.getCedula());

        System.out.println("Cliente: " + cliente.getNombre() + " " + cliente.getApellido1() + " " + cliente.getApellido2());

        if (cantidadCompras > promedioCompras) {
            System.out.println("Descuento del 10% en la próxima venta.");
        } else if (cantidadCompras < promedioCompras) {
            System.out.println("Descuento del 15% en la próxima compra.");
        } else {
            System.out.println("Descuento del 25% en la primera compra.");
        }
    }
}



    private double calcularPromedioCompras() {
        double totalCompras = libretaVentas.getVentas().size();
        double totalClientes = libretaClientes.getClientes().size();
        return totalCompras / totalClientes;
    }

    private int contarComprasCliente(String cedulaCliente) {
        int cantidadCompras = 0;

        for (Venta venta : libretaVentas.getVentas()) {
            if (venta.getCedulaCliente().equals(cedulaCliente)) {
                cantidadCompras++;
            }
        }

        return cantidadCompras;
    }
}

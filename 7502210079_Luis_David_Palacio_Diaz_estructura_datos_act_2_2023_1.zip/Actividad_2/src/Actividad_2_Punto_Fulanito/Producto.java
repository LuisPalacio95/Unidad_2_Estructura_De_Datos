/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Producto {
    private int codigo;
    private String nombre;
    private String marca;
    private String color;
    private double precioCompra;
    private double precioVenta;
    private double porcentajeDescuentoMaximo;
    private int unidadesExistencia;
    private String metricaMedida;
    private String categoria;

    public Producto(int codigo, String nombre, String marca, String color, double precioCompra, double precioVenta,
                    double porcentajeDescuentoMaximo, int unidadesExistencia, String metricaMedida, String categoria) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.color = color;
        this.precioCompra = precioCompra;
        this.precioVenta = precioVenta;
        this.porcentajeDescuentoMaximo = porcentajeDescuentoMaximo;
        this.unidadesExistencia = unidadesExistencia;
        this.metricaMedida = metricaMedida;
        this.categoria = categoria;
    }

    // Getters y setters

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
    }

    public double getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(double precioVenta) {
        this.precioVenta = precioVenta;
    }

    public double getPorcentajeDescuentoMaximo() {
        return porcentajeDescuentoMaximo;
    }

    public void setPorcentajeDescuentoMaximo(double porcentajeDescuentoMaximo) {
        this.porcentajeDescuentoMaximo = porcentajeDescuentoMaximo;
    }

    public int getUnidadesExistencia() {
        return unidadesExistencia;
    }

    public void setUnidadesExistencia(int unidadesExistencia) {
        this.unidadesExistencia = unidadesExistencia;
    }

    public String getMetricaMedida() {
        return metricaMedida;
    }

    public String getCategoria() {
        return categoria;
    }
}

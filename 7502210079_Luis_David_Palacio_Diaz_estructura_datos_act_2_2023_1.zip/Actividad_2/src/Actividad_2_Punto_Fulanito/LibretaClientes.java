/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class LibretaClientes {
    private List<Cliente> clientes;

    public LibretaClientes() {
        clientes = new ArrayList<>();
    }

    public void anotarClienteEnLibreta(String cedula, String nombre, String apellido1, String apellido2, String genero,
                                       String fechaNacimiento, String numeroTelefonico, String email, String direccion,
                                       boolean esVIP, double descuento) {
        Cliente cliente = new Cliente(cedula, nombre, apellido1, apellido2, genero, fechaNacimiento,
                numeroTelefonico, email, direccion, esVIP, descuento);
        clientes.add(cliente);
    }

    public List<Cliente> getClientes() {
        return clientes;
    }
}

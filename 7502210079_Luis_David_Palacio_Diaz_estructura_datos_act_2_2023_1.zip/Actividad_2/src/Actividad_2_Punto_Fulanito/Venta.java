/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

import java.util.List;

/**
 *
 * @author Mr Palacio
 */
class Venta {
    private int consecutivo;
    private String fecha;
    private String cedulaCliente;
    private String medioPago;
    private String modalidad;
    private List<ItemVenta> itemsVenta;
    private String estado;
    private String motivoCancelacion;

    public Venta(int consecutivo, String fecha, String cedulaCliente, String medioPago, String modalidad,
                 List<ItemVenta> itemsVenta) {
        this.consecutivo = consecutivo;
        this.fecha = fecha;
        this.cedulaCliente = cedulaCliente;
        this.medioPago = medioPago;
        this.modalidad = modalidad;
        this.itemsVenta = itemsVenta;
        this.estado = "Pendiente";
        this.motivoCancelacion = "";
    }

    // Getters y setters

    public int getConsecutivo() {
        return consecutivo;
    }

    public String getFecha() {
        return fecha;
    }

    public String getCedulaCliente() {
        return cedulaCliente;
    }

    public String getMedioPago() {
        return medioPago;
    }

    public String getModalidad() {
        return modalidad;
    }

    public List<ItemVenta> getItemsVenta() {
        return itemsVenta;
    }

    public double getTotal() {
        double total = 0.0;
        for (ItemVenta item : itemsVenta) {
            total += (item.getPrecioVenta() * item.getCantidad()) - item.getValorDescuento();
            total += (item.getPrecioVenta() * item.getCantidad()) - item.getValorDescuento();
        }
        return total;
    }

    public double getTotalIVA() {
        double totalIVA = 0.0;
        double total = getTotal();
        totalIVA = total * 0.19; // Impuesto IVA del 19%
        return totalIVA;
    }

    public double getTotalDescuento() {
        double totalDescuento = 0.0;
        for (ItemVenta item : itemsVenta) {
            totalDescuento += item.getValorDescuento();
        }
        return totalDescuento;
    }

    public double getTotalSinIVA() {
        double totalSinIVA = getTotal() - getTotalIVA();
        return totalSinIVA;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMotivoCancelacion() {
        return motivoCancelacion;
    }

    public void setMotivoCancelacion(String motivoCancelacion) {
        this.motivoCancelacion = motivoCancelacion;
    }
}

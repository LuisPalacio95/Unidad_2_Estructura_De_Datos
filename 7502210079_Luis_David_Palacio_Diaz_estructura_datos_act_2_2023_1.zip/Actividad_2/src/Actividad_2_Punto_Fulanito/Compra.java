/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
class Compra {
    private int consecutivo;
    private String fecha;
    private String proveedor;
    private int codigoProducto;
    private double precioCompra;
    private double cantidad;

    public Compra(int consecutivo, String fecha, String proveedor, int codigoProducto, double precioCompra,
                  double cantidad) {
        this.consecutivo = consecutivo;
        this.fecha = fecha;
        this.proveedor = proveedor;
        this.codigoProducto = codigoProducto;
        this.precioCompra = precioCompra;
        this.cantidad = cantidad;
    }

    // Getters

    public int getConsecutivo() {
        return consecutivo;
    }

    public String getFecha() {
        return fecha;
    }

    public String getProveedor() {
        return proveedor;
    }

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public double getCantidad() {
        return cantidad;
    }
}


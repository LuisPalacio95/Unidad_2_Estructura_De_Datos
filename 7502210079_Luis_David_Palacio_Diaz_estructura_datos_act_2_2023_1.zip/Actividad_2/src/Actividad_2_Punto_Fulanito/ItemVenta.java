/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
class ItemVenta {
    private int codigoProducto;
    private double precioVenta;
    private double cantidad;
    private double valorDescuento;

    public ItemVenta(int codigoProducto, double precioVenta, double cantidad, double valorDescuento) {
        this.codigoProducto = codigoProducto;
        this.precioVenta = precioVenta;
        this.cantidad = cantidad;
        this.valorDescuento = valorDescuento;
    }

    // Getters

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public double getPrecioVenta() {
        return precioVenta;
    }

    public double getCantidad() {
        return cantidad;
    }

    public double getValorDescuento() {
        return valorDescuento;
    }
}
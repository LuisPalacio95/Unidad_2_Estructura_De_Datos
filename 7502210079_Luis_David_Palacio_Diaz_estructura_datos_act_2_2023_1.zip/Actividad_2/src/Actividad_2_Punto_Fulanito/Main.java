/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {

    public static void main(String[] args) {
        Persona luis = new Persona("LUIS");

        // Punto 1: Anotar productos en la libreta
        luis.anotarProductoEnLibreta(1, "Producto 1", "Marca 1", "Rojo", 10.0, 0.0, 0.0, 0, "kg", "Categoría 1");
        luis.anotarProductoEnLibreta(2, "Producto 2", "Marca 2", "Azul", 15.0, 0.0, 0.0, 0, "litros", "Categoría 2");
        luis.anotarProductoEnLibreta(3, "Producto 3", "Marca 3", "Verde", 20.0, 0.0, 0.0, 0, "metros", "Categoría 1");

        // Punto 2: Anotar compras en la libreta
        luis.anotarCompraEnLibreta(1, "2023-07-07", "Proveedor 1", 1, 10.0, 2);
        luis.anotarCompraEnLibreta(2, "2023-07-07", "Proveedor 2", 2, 15.0, 3);
        luis.anotarCompraEnLibreta(3, "2023-07-07", "Proveedor 3", 3, 20.0, 4);

        // Punto 3: Realizar venta
        List<ItemVenta> itemsVenta = new ArrayList<>();
        itemsVenta.add(new ItemVenta(1, 0.0, 2, 0.0));
        itemsVenta.add(new ItemVenta(2, 0.0, 3, 0.0));
        luis.realizarVenta(1, "2023-07-07", "1234567890", "Efectivo", "Directa", itemsVenta);

        // Punto 4: Consultar productos con unidades de existencia > 0
        System.out.println();
        luis.mostrarProductosBajoExistencia();

        // Punto 5: Calcular balance financiero
        System.out.println();
        luis.calcularBalanceFinanciero();

        // Punto 6: Calcular productos de inversión recomendada y aplicar descuento a los no exitosos
        List<Producto> productosInversionRecomendada = luis.obtenerProductosInversionRecomendada();
        luis.aplicarDescuentoProductosNoExitosos(productosInversionRecomendada);

        System.out.println();
        luis.anotarClienteEnLibreta("45500269", "Saulo David", "Ballesteros", "Viloria", "Femenino",
                "2000-01-01", "123456789", "cliente1@gmail.com", "Dirección", false, 0.0);
        luis.anotarClienteEnLibreta("1143386500", "Luis David", "Palacio", "Diaz", "Masculino",
                "1995-05-05", "234567890", "cliente2@gmail.com", "Dirección", false, 0.0);
        luis.anotarClienteEnLibreta("1047474793", "Luis Angel", "Vallejo", "Vallejo", "Femenino",
                "1980-12-31", "345678901", "cliente3@gmail.com", "Dirección", false, 0.0);

        // Punto 7: Informar descuentos a los clientes
        System.out.println();
        luis.informarDescuentosClientes();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class LibretaVentas {
    private List<Venta> ventas;

    public LibretaVentas() {
        ventas = new ArrayList<>();
    }

    public void anotarVentaEnLibreta(int consecutivo, String fecha, String cedulaCliente, String medioPago,
                                     String modalidad, List<ItemVenta> itemsVenta) {
        Venta venta = new Venta(consecutivo, fecha, cedulaCliente, medioPago, modalidad, itemsVenta);
        ventas.add(venta);
    }

    public List<Venta> getVentas() {
        return ventas;
    }
}

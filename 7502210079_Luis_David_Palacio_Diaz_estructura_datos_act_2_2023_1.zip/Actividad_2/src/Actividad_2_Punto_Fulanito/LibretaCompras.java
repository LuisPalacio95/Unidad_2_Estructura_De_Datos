/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class LibretaCompras {
    private List<Compra> compras;

    public LibretaCompras() {
        compras = new ArrayList<>();
    }

    public void anotarCompraEnLibreta(int consecutivo, String fecha, String proveedor, int codigoProducto,
                                      double precioCompra, double cantidad) {
        Compra compra = new Compra(consecutivo, fecha, proveedor, codigoProducto, precioCompra, cantidad);
        compras.add(compra);
    }

    public List<Compra> getCompras() {
        return compras;
    }
}

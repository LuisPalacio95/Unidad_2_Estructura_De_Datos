/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
class Cliente {
    private String cedula;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String genero;
    private String fechaNacimiento;
    private String numeroTelefonico;
    private String email;
    private String direccion;
    private boolean esVIP;
    private double descuento;

    public Cliente(String cedula, String nombre, String apellido1, String apellido2, String genero,
                   String fechaNacimiento, String numeroTelefonico, String email, String direccion, boolean esVIP, double descuento) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.genero = genero;
        this.fechaNacimiento = fechaNacimiento;
        this.numeroTelefonico = numeroTelefonico;
        this.email = email;
        this.direccion = direccion;
        this.esVIP = esVIP;
        this.descuento = descuento;
    }

    // Getters

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public String getGenero() {
        return genero;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getNumeroTelefonico() {
        return numeroTelefonico;
    }

    public String getEmail() {
        return email;
    }

    public String getDireccion() {
        return direccion;
    }

    public boolean esVIP() {
        return esVIP;
    }

    public void setEsVIP(boolean esVIP) {
        this.esVIP = esVIP;
    }

    public double getDescuento() {
        return descuento;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_Fulanito;

/**
 *
 * @author Mr Palacio
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class LibretaProductos {
    private List<Producto> productos;

    public LibretaProductos() {
        productos = new ArrayList<>();
    }

    public void anotarProductoEnLibreta(int codigo, String nombre, String marca, String color, double precioCompra,
                                        double precioVenta, double porcentajeDescuentoMaximo, int unidadesExistencia,
                                        String metricaMedida, String categoria) {
        Producto producto = new Producto(codigo, nombre, marca, color, precioCompra, precioVenta,
                porcentajeDescuentoMaximo, unidadesExistencia, metricaMedida, categoria);
        productos.add(producto);
    }

    public List<Producto> getProductos() {
        return productos;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_1_3;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

class Nodo {

    int valor;
    Nodo siguiente;

    // Constructor 
    public Nodo(int valor, Nodo siguiente) {
        this.valor = valor;
        this.siguiente = siguiente;
    }
}

public class ListaEnlazadaAlgoritmosOrdenamiento {

    Nodo primerElemento = null;

    void agregar(int valor) {
        System.out.println("Insertando el valor: " + valor);

        Nodo nuevoNodo = new Nodo(valor, null);

        if (primerElemento != null) {

            Nodo nodoActual = primerElemento;
            Nodo nodoAnterior = null;

            while (nodoActual != null && nodoActual.valor < valor) {
                nodoAnterior = nodoActual;
                nodoActual = nodoActual.siguiente;
            }

            if (primerElemento == nodoActual) {
                primerElemento = nuevoNodo;
            } else {
                nodoAnterior.siguiente = nuevoNodo;
            }

            nuevoNodo.siguiente = nodoActual;
        } else {
            primerElemento = nuevoNodo;
        }
    }

    void listar() {
        if (primerElemento != null) {
            Nodo actual = primerElemento;

            System.out.println("Los elementos de la lista ordenada son : ");

            while (actual != null) {
                System.out.print(actual.valor + " ");
                actual = actual.siguiente;
            }
            System.out.println();
        } else {
            System.out.println("La lista esta vacia");
        }
    }

    void buscar(int valor) {
        boolean encontrado = false;
        Nodo nodoActual = primerElemento;

        while (nodoActual != null && nodoActual.valor <= valor) {
            if (nodoActual.valor == valor) {
                encontrado = true;
                break;
            }
            nodoActual = nodoActual.siguiente;
        }

        if (encontrado) {
            System.out.println("El valor " + valor + " se encontro en la lista");
        } else {
            System.out.println("El valor " + valor + " no se encontro en la lista");
        }
    }

    void eliminar(int valor) {
        if (primerElemento != null) {
            Nodo nodoEliminar = primerElemento;
            Nodo nodoAnterior = null;

            while (nodoEliminar != null && nodoEliminar.valor != valor) {
                nodoAnterior = nodoEliminar;
                nodoEliminar = nodoEliminar.siguiente;
            }

            if (nodoEliminar == null) {
                System.out.println("Este valor no fue hallado en la lista");
            } else if (nodoAnterior == null) {
                primerElemento = primerElemento.siguiente;
                System.out.println("El valor " + valor + " fue hallado y eliminado");
            } else {
                nodoAnterior.siguiente = nodoEliminar.siguiente;
                System.out.println("El valor " + valor + " fue hallado y eliminado");
            }
        }
    }

    void limpiarTodo() {
        primerElemento = null;
        System.out.println("Se elimino todo de la lista");
    }

    void OrdenamientoBurbuja() {
        Nodo nodoActual;
        Nodo siguienteNodo;
        int temp;

        if (primerElemento == null) {
            System.out.println("La lista está vacía");
            return;
        }

        boolean intercambiado;
        do {
            intercambiado = false;
            nodoActual = primerElemento;

            while (nodoActual.siguiente != null) {
                siguienteNodo = nodoActual.siguiente;

                if (nodoActual.valor > siguienteNodo.valor) {
                    temp = nodoActual.valor;
                    nodoActual.valor = siguienteNodo.valor;
                    siguienteNodo.valor = temp;
                    intercambiado = true;
                }

                nodoActual = siguienteNodo;
            }
        } while (intercambiado);
    }

    void OrdenamientoInsercion() {
        if (primerElemento == null) {
            System.out.println("La lista está vacía");
            return;
        }

        Nodo nodoActual = primerElemento.siguiente;
        while (nodoActual != null) {
            int valorActual = nodoActual.valor;
            Nodo nodoPrevio = nodoActual;

            while (nodoPrevio != null && nodoPrevio.valor > valorActual) {
                nodoPrevio.siguiente.valor = nodoPrevio.valor;
                nodoPrevio = nodoPrevio.siguiente;
            }

            nodoPrevio.valor = valorActual;
            nodoActual = nodoActual.siguiente;
        }
    }

    void OrdenamientoSeleccion() {
        if (primerElemento == null) {
            System.out.println("La lista está vacía");
            return;
        }

        Nodo nodoActual = primerElemento;
        while (nodoActual != null) {
            Nodo nodoMinimo = nodoActual;
            Nodo siguienteNodo = nodoActual.siguiente;

            while (siguienteNodo != null) {
                if (siguienteNodo.valor < nodoMinimo.valor) {
                    nodoMinimo = siguienteNodo;
                }
                siguienteNodo = siguienteNodo.siguiente;
            }

            int temp = nodoActual.valor;
            nodoActual.valor = nodoMinimo.valor;
            nodoMinimo.valor = temp;

            nodoActual = nodoActual.siguiente;
        }
    }

    public static void main(String[] args) {

        ListaEnlazadaAlgoritmosOrdenamiento lista = new ListaEnlazadaAlgoritmosOrdenamiento();

        System.out.println("\nAlgoritmo de ordenamiento burbuja");

        lista.agregar(322);
        lista.agregar(41);
        lista.agregar(22);
        lista.agregar(278);
        lista.agregar(18);
        lista.agregar(233);

        lista.OrdenamientoBurbuja();
        lista.listar();

        lista.buscar(278);

        lista.eliminar(278);

        lista.listar();

        lista.limpiarTodo();

        lista.listar();

        System.out.println("\nAlgoritmo de ordenamiento insercion");

        lista.agregar(5);
        lista.agregar(4);
        lista.agregar(232);
        lista.agregar(2000);
        lista.agregar(3452);
        lista.agregar(9);

        lista.OrdenamientoInsercion();

        lista.listar();

        lista.buscar(278);

        lista.eliminar(278);

        lista.listar();

        lista.limpiarTodo();

        lista.listar();

        System.out.println("\nAlgoritmo de ordenamiento seleccion");

        lista.agregar(98);
        lista.agregar(65);
        lista.agregar(140);
        lista.agregar(20);
        lista.agregar(9);
        lista.agregar(444);

        lista.OrdenamientoInsercion();

        lista.listar();

        lista.buscar(444);

        lista.eliminar(444);

        lista.listar();

        lista.limpiarTodo();

        lista.listar();

    }
}

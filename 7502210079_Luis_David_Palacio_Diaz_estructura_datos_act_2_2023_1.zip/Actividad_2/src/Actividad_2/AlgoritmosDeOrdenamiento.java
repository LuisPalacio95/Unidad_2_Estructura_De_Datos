/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

public class AlgoritmosDeOrdenamiento {

    public static void main(String[] args) {

        List<Integer> lista = new ArrayList<>(Arrays.asList(322, 41, 22, 278, 18, 233));
        System.out.println("IMPRESION DE ALGORITMOS DE ORDENAMIENTO - LUIS DAVID PALACIO DIAZ "
                + "\nImpresion de la lista en desorden antes : " + lista + "\n");

        //1.  Ordenamiento Burbuja:
        List<Integer> ListaOrdenamientoBurbuja = new ArrayList<>(lista);
        OrdenamientoBurbuja(ListaOrdenamientoBurbuja);
        System.out.println("1. Impresion algoritmo de ordenamiento burbuja: " + ListaOrdenamientoBurbuja);

        //2.  Ordenamiento por insercion (Insertion sort):
        List<Integer> ListaOrdenamientoInsercion = new ArrayList<>(lista);
        OrdenamientoInsercion(ListaOrdenamientoInsercion);
        System.out.println("2. Impresion algoritmo de ordenamiento por insercion: " + ListaOrdenamientoInsercion);

        //3.  Ordenamiento por seleccion (Selection sort):
        List<Integer> ListaOrdenamientoSeleccion = new ArrayList<>(lista);
        OrdenamientoSeleccion(ListaOrdenamientoSeleccion);
        System.out.println("3. Impresion algoritmo de ordenamiento seleccion: " + ListaOrdenamientoSeleccion);

        //4.  Ordenamiento Shell (Shell sort):
        List<Integer> ListaOrdenamientoShell = new ArrayList<>(lista);
        OrdenamientoShell(ListaOrdenamientoShell);
        System.out.println("4. Impresion algoritmo de ordenamiento shell: " + ListaOrdenamientoShell);

        //5.  OrdenamientoCasilleros (Counting sort):
        List<Integer> ListaOrdenamientoCasilleros = new ArrayList<>(lista);
        OrdenamientoCasilleros(ListaOrdenamientoCasilleros);
        System.out.println("5. Impresion algoritmo de ordenamiento casilleros: " + ListaOrdenamientoCasilleros);

        //6.  OrdenamientoPanqueques (Pancake sorting):
        List<Integer> ListaOrdenamientoPanqueques = new ArrayList<>(lista);
        System.out.println("6. Impresion algoritmo de ordenamiento panqueques en desorden: " + ListaOrdenamientoPanqueques);
        OrdenamientoPanqueques(ListaOrdenamientoPanqueques);
        System.out.println("6. Impresion algoritmo de ordenamiento panqueques ordenados: " + ListaOrdenamientoPanqueques);

        //7.  OrdenamientoMezcla (Merge sort): 
        List<Integer> ListaOrdenamientoMezcla = new ArrayList<>(lista);
        OrdenamientoMezcla(ListaOrdenamientoMezcla);
        System.out.println("7. Impresion algoritmo de ordenamiento mezcla: " + ListaOrdenamientoMezcla);

        //8.  OrdenamientoRapido (Quick sort):
        List<Integer> ListaOrdenamientoRapido = new ArrayList<>(lista);
        OrdenamientoRapido(ListaOrdenamientoRapido);
        System.out.println("8. Impresion algoritmo de ordenamiento rapido: " + ListaOrdenamientoRapido);

        //9.  OrdenamientoGnomeSort (Stupid sort):
        List<Integer> ListaOrdenamientoGnomeSort = new ArrayList<>(lista);
        OrdenamientoGnomeSort(ListaOrdenamientoGnomeSort);
        System.out.println("9. Impresion algoritmo de ordenamiento GnomeSort: " + ListaOrdenamientoGnomeSort);

        //10. OrdenamientoCombSort:
        List<Integer> ListaOrdenamientoCombSort = new ArrayList<>(lista);
        OrdenamientoCombSort(ListaOrdenamientoCombSort);
        System.out.println("10. Impresion algoritmo de ordenamiento CombSort: " + ListaOrdenamientoCombSort);
    }

    //1.  Ordenamiento Burbuja:
    public static void OrdenamientoBurbuja(List<Integer> lista) {
        int l = lista.size();
        for (int i = 0; i < l - 1; i++) {
            for (int k = 0; k < l - i - 1; k++) {
                if (lista.get(k) > lista.get(k + 1)) {
                    int temp = lista.get(k);
                    lista.set(k, lista.get(k + 1));
                    lista.set(k + 1, temp);
                }
            }
        }
    }

    //2.  Ordenamiento por insercion (Insertion sort):
    public static void OrdenamientoInsercion(List<Integer> lista) {
        int l = lista.size();
        for (int i = 1; i < l; i++) {
            int Valor_Actual = lista.get(i);
            int k = i - 1;
            while (k >= 0 && lista.get(k) > Valor_Actual) {
                lista.set(k + 1, lista.get(k));
                k--;
                lista.set(k + 1, Valor_Actual);
            }
        }
    }

    //3.  Ordenamiento por seleccion (Selection sort):
    public static void OrdenamientoSeleccion(List<Integer> lista) {
        int l = lista.size();
        for (int p = 0; p < l - 1; p++) {
            int indMin = p;
            for (int k = p + 1; k < l; k++) {
                if (lista.get(k) < lista.get(indMin)) {
                    indMin = k;
                }
            }
            int temp = lista.get(indMin);
            lista.set(indMin, lista.get(p));
            lista.set(p, temp);
        }
    }

    //4.  Ordenamiento Shell (Shell sort):
    public static void OrdenamientoShell(List<Integer> lista) {
        int k = lista.size();
        int tamBre = k / 2;
        while (tamBre > 0) {
            for (int i = tamBre; i < k; i++) {
                int vlrActual = lista.get(i);
                int p = i;

                while (p >= tamBre && lista.get(p - tamBre) > vlrActual) {
                    lista.set(p, lista.get(p - tamBre));
                    p -= tamBre;
                }
                lista.set(p, vlrActual);
            }
            tamBre /= 2;
        }
    }

    //5.  OrdenamientoCasilleros (Counting sort):
    public static void OrdenamientoCasilleros(List<Integer> lista) {
        //De esta manera podemos hallar el valor maximo en la lista
        int maximo = Integer.MIN_VALUE;
        for (int num : lista) {
            if (num > maximo) {
                maximo = num;
            }
        }

        //Creamos un arreglo aux de contadores
        int[] contador = new int[maximo + 1];

        // Aqui se puede contar la frecuencia de cada uno de los elementos en nuestra lista
        for (int num : lista) {
            contador[num]++;
        }

        //En este punto estaremos reconstruyendo la lista ordenada
        int index = 0;
        for (int i = 0; i < contador.length; i++) {
            while (contador[i] > 0) {
                lista.set(index, i);
                index++;
                contador[i]--;
            }
        }
    }

    //6.  OrdenamientoPanqueques (Pancake sorting):
    public static void OrdenamientoPanqueques(List<Integer> numeros) {
        for (int i = numeros.size() - 1; i >= 0; i--) {
            int indiceMaximo = 0;
            for (int j = 1; j <= i; j++) {
                if (numeros.get(j) > numeros.get(indiceMaximo)) {
                    indiceMaximo = j;
                }
            }
            invertir(numeros, indiceMaximo + 1);
            invertir(numeros, i + 1);
        }
    }

    private static void invertir(List<Integer> numeros, int k) {
        List<Integer> subListaNumeros = numeros.subList(0, k);
        for (int i = 0; i < subListaNumeros.size() / 2; i++) {
            int temp = subListaNumeros.get(i);
            subListaNumeros.set(i, subListaNumeros.get(k - i - 1));
            subListaNumeros.set(k - i - 1, temp);
        }
    }

    //7.  OrdenamientoMezcla (Merge sort): 
    public static void OrdenamientoMezcla(List<Integer> numeros) {
        if (numeros.size() <= 1) {
            return;
        }
        int medio = numeros.size() / 2;
        List<Integer> izquierda = new ArrayList<>(numeros.subList(0, medio));
        List<Integer> derecha = new ArrayList<>(numeros.subList(medio, numeros.size()));
        OrdenamientoMezcla(izquierda);
        OrdenamientoMezcla(derecha);
        int indiceIzq = 0, indiceDer = 0, indiceResultado = 0;
        while (indiceIzq < izquierda.size() && indiceDer < derecha.size()) {
            if (izquierda.get(indiceIzq) <= derecha.get(indiceDer)) {
                numeros.set(indiceResultado++, izquierda.get(indiceIzq++));
            } else {
                numeros.set(indiceResultado++, derecha.get(indiceDer++));
            }
        }
        while (indiceIzq < izquierda.size()) {
            numeros.set(indiceResultado++, izquierda.get(indiceIzq++));
        }
        while (indiceDer < derecha.size()) {
            numeros.set(indiceResultado++, derecha.get(indiceDer++));
        }
    }

    //8.  OrdenamientoRapido (Quick sort):
    public static void OrdenamientoRapido(List<Integer> lista) {
        OrdenamientoRapido(lista, 0, lista.size() - 1);
    }

    private static void OrdenamientoRapido(List<Integer> lista, int inicio, int fin) {
        if (inicio >= fin) {
            return;
        }
        int indicePivote = division(lista, inicio, fin);
        OrdenamientoRapido(lista, inicio, indicePivote - 1);
        OrdenamientoRapido(lista, indicePivote + 1, fin);
    }

    private static int division(List<Integer> lista, int inicio, int fin) {
        int pivote = lista.get(fin);
        int indiceMenor = inicio;
        for (int i = inicio; i < fin; i++) {
            if (lista.get(i) < pivote) {
                int temp = lista.get(i);
                lista.set(i, lista.get(indiceMenor));
                lista.set(indiceMenor, temp);
                indiceMenor++;
            }
        }
        int temp = lista.get(indiceMenor);
        lista.set(indiceMenor, lista.get(fin));
        lista.set(fin, temp);
        return indiceMenor;
    }

    //9.  OrdenamientoGnomeSort (Stupid sort):
    public static void OrdenamientoGnomeSort(List<Integer> lista) {
        int indice = 0;

        while (indice < lista.size()) {
            if (indice == 0 || lista.get(indice) >= lista.get(indice - 1)) {
                indice++;
            } else {
                int temp = lista.get(indice);
                lista.set(indice, lista.get(indice - 1));
                lista.set(indice - 1, temp);
                indice--;
            }
        }
    }

    //10.  OrdenamientoCombSort
    public static void OrdenamientoCombSort(List<Integer> lista) {
        int n = lista.size();
        int brecha = n;
        boolean intercambio = true;

        while (brecha > 1 || intercambio) {
            if (brecha > 1) {
                brecha = (int) (brecha / 1.3);
            }

            intercambio = false;

            for (int i = 0; i < n - brecha; i++) {
                if (lista.get(i) > lista.get(i + brecha)) {
                    int temp = lista.get(i);
                    lista.set(i, lista.get(i + brecha));
                    lista.set(i + brecha, temp);
                    intercambio = true;
                }
            }
        }
    }
}

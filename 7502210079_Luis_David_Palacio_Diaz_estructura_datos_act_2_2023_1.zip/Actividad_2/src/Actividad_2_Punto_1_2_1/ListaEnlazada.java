/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actividad_2_Punto_1_2_1;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

class Nodo {

    int valor;
    Nodo siguiente;

    //Constructor
    public Nodo(int valor, Nodo siguiente) {
        this.valor = valor;
        this.siguiente = siguiente;
    }
}

public class ListaEnlazada {

    Nodo primerElemento = null;

    void agregar(int valor) {
        System.out.println("Insertando el valor: " + valor);

        Nodo nuevoNodo = new Nodo(valor, null);

        if (primerElemento != null) {
            Nodo nodoActual = primerElemento;
            Nodo nodoAnterior = null;

            while (nodoActual != null && nodoActual.valor < valor) {
                nodoAnterior = nodoActual;
                nodoActual = nodoActual.siguiente;
            }

            if (primerElemento == nodoActual) {
                primerElemento = nuevoNodo;
            } else {
                nodoAnterior.siguiente = nuevoNodo;
            }

            nuevoNodo.siguiente = nodoActual;
        } else {
            primerElemento = nuevoNodo;
        }
    }

    void listar() {
        if (primerElemento != null) {
            Nodo actual = primerElemento;

            System.out.println("Los elementos en la lista son: ");

            while (actual != null) {
                System.out.print(actual.valor + " ");
                actual = actual.siguiente;
            }
            System.out.println();
        } else {
            System.out.println("La lista esta vacia");
        }
    }

    void buscar(int valor) {
        boolean encontrado = false;
        Nodo nodoActual = primerElemento;

        while (nodoActual != null && nodoActual.valor <= valor) {
            if (nodoActual.valor == valor) {
                encontrado = true;
                break;
            }
            nodoActual = nodoActual.siguiente;
        }

        if (encontrado) {
            System.out.println("El valor " + valor + " se encontro en la lista");
        } else {
            System.out.println("El valor " + valor + " no se encontro en la lista");
        }
    }

    void eliminar(int valor) {
        if (primerElemento != null) {
            Nodo nodoEliminar = primerElemento;
            Nodo nodoAnterior = null;

            while (nodoEliminar != null && nodoEliminar.valor != valor) {
                nodoAnterior = nodoEliminar;
                nodoEliminar = nodoEliminar.siguiente;
            }

            if (nodoEliminar == null) {
                System.out.println("Este valor no fue hallado en la lista");
            } else if (nodoAnterior == null) {
                primerElemento = primerElemento.siguiente;
                System.out.println("El valor " + valor + " fue hallado y eliminado");
            } else {
                nodoAnterior.siguiente = nodoEliminar.siguiente;
                System.out.println("El valor " + valor + " fue hallado y eliminado");
            }
        }
    }

    void limpiarTodo() {
        primerElemento = null;
        System.out.println("Se elimino todo de la lista");
    }

    public static void main(String[] args) {

        ListaEnlazada lista = new ListaEnlazada();

        lista.agregar(322);
        lista.agregar(41);
        lista.agregar(22);
        lista.agregar(278);
        lista.agregar(18);
        lista.agregar(233);

        lista.listar();

        lista.buscar(278);

        lista.eliminar(278);

        lista.listar();

        lista.limpiarTodo();

        lista.listar();
    }
}
